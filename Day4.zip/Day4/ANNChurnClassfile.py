# -*- coding: utf-8 -*-
"""
Created on Mon May 30 15:52:35 2022
Binary Classification - Discrete value prediction
@author: TSE
"""
# =============================================================================
# Import of Libaries
# =============================================================================
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# =============================================================================
# Data Import and Feature Extraction
# =============================================================================
dataset = pd.read_csv('Churn Modelling-Bank Customers.csv')

X = dataset.iloc[:, 3:13]     # X dataframe 
y = dataset.iloc[:, 13].values  # y array

# =============================================================================
# Encoding Georgraphy and Gender Column
# =============================================================================
X = pd.get_dummies(X, columns=['Geography','Gender'],drop_first=True)

X = X.values   # convert dataframe to Numpy array

# =============================================================================
# Train-Test 80-20 Split
# =============================================================================
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=0)

# =============================================================================
# Scaling of Values
# =============================================================================
from sklearn.preprocessing import StandardScaler
scObj = StandardScaler()

X_train = scObj.fit_transform(X_train)
X_test = scObj.transform(X_test)

# =============================================================================
# NEURAL NETWORK IMPLEMENTATION
# =============================================================================
import keras
from keras.models import Sequential          # NN initialization
from keras.layers import Dense               # Adding Layers

# =============================================================================
# Object of Sequential for NN Initialization
# =============================================================================





















